from setuptools import setup

setup (
    name="Paquete calculos",
    version="1.0",
    description="Paquete de redondeo y potencia",
    author="ahidalgoma",
    author_email="angel.hidalgo.marin@hotmail.com",
    url="www.iqlim.net",
    package=["calculos", "calculos.redondeo_potencia"]

    )