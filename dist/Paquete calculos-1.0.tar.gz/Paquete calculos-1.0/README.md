# cursopython
Curso de python inicial
